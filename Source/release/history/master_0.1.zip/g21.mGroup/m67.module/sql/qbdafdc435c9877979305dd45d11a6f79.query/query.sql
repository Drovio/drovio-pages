SELECT *
FROM RB_person
WHERE mail = '{email}' AND activated = 0;