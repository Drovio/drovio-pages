UPDATE PLM_account
SET title = '{title}', description = '{description}'
WHERE id = {aid};