UPDATE RB_person
SET username = '{username}' 
WHERE RB_person.id = {pid}