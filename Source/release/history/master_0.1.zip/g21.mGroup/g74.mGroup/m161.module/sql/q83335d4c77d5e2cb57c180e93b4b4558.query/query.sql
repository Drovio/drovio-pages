UPDATE PLM_account
SET password = '{password}'
WHERE PLM_account.id = {id};