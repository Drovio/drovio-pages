INSERT IGNORE INTO PLM_accountToTeam (account_id, team_id)
VALUES ({aid}, {tid});