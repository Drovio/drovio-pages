SELECT PLM_userGroup.id, PLM_userGroup.name
FROM PLM_userGroup
WHERE PLM_userGroup.name LIKE 'TEAM_%'