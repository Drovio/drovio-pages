<?php
//#section#[header]
// Module Declaration
$moduleID = 127;

// Inner Module Codes
$innerModules = array();
$innerModules['templateObject'] = 117;

// Check Module Preloader Defined in RB Platform (prevent outside executions)
if (!defined("_MDL_PRELOADER_") && !defined("_RB_PLATFORM_"))
	throw new Exception("Module is not loaded properly!");

// Require Importer
use \API\Platform\importer;

// Import Initial Libraries
importer::import("UI", "Html", "DOM");

// New
use \UI\Html\DOM;

// Code Variables
$_ASCOP = $GLOBALS['_ASCOP'];

// If Async Request Pre-Loader exists, Initialize DOM
if (defined("_MDL_PRELOADER_"))
	DOM::initialize();

// Import Packages
importer::import("API", "Developer");
importer::import("UI", "Forms");
importer::import("UI", "Navigation");
importer::import("INU", "Forms");
importer::import("INU", "Developer");
//#section_end#
//#section#[code]
use \API\Developer\ebuilder\template;
use \INU\Developer\redWIDE;
use \INU\Developer\cssEditor;
use \INU\Forms\HTMLEditor;
use \UI\Navigation\navigationBar;
use \UI\Navigation\toolbarComponents\toolbarItem;
use \UI\Forms\templates\simpleForm;


$pageStructureName = $_GET['pageStructure'];
$templateID = $_GET['templateId'];
$editorPool = $_GET['editorPool'];

$templateManager = new template();
$templateManager->load($templateID);

// Create global layout object whapper
$globalObjectWhapper = DOM::create("div");

// Add attributes to global whapper		
DOM::attr($globalObjectWhapper, "style", "height:100%;");

// #Object Content
// ##Create object Form
$objectForm_builder = new simpleForm();
$objectForm = $objectForm_builder->build($innerModules['templateObject'], "savePageStructure", $controls = FALSE);
DOM::append($globalObjectWhapper, $objectForm_builder->get());

// ###Hidden Values
// ####Name
$input = $objectForm_builder->getInput($type = "hidden", $name = "name", $pageStructureName, $class = "", $autofocus = FALSE);
$objectForm_builder->append($input);


// ###Content Wrapper
$obj_container = DOM::create('div');
$objectForm_builder->append($obj_container);

// ##Toolbar
// Toolbar Control 
$tlb = new navigationBar();
$tlbItemBuilder = new toolbarItem();
// Create Source Code Manager Toolbar;
$sideToolArea = $tlb->build($dock = "T", $obj_container)->get();
DOM::append($obj_container, $sideToolArea); 


// #####Save Tool
$content = DOM::create("button", "",  "saveModel_".$_GET['pageStructure'], "sideTool save saveModule");
DOM::attr($content, "type", "submit");
$saveTool = $tlbItemBuilder->build($content)->get();
$tlb->insertTool($saveTool);

// Css Style Code Editor
/*
$css_codeEditor= new cssEditor("objectCSS", "objectXML");
$code = $templateManager->getStructureCSS($pageStructureName);
$structure = $templateManager->getStructureXML($pageStructureName, TRUE);
$css_editor = $css_codeEditor->build($structure, $code)->get();
DOM::append($obj_container, $css_editor);
*/

//
$HTML_EDITOR = new HTMLEditor();
$structure = $templateManager->getStructureXML($pageStructureName, TRUE);
$HTML_EDITOR->build($structure, "htmlContent",  HTMLEditor::HTML_DESIGNER);


DOM::append($obj_container, $HTML_EDITOR->get());


// Prepare report
// Send redWIDE Tab
$obj_id = "ps_".$pageStructureName;
$header = $pageStructureName;
$WIDETab = new redWIDE();
return $WIDETab->getReportContent($obj_id, $header, $globalObjectWhapper, $editorPool);
//#section_end#
?>