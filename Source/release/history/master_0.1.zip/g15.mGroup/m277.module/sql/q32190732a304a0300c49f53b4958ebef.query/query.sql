SELECT COUNT(*) as count
FROM RB_team