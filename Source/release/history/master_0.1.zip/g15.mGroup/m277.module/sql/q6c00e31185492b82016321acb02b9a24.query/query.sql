SELECT COUNT(*) AS count
FROM DEV_project