SELECT COUNT(*) AS count
FROM RB_person
WHERE activated = 1