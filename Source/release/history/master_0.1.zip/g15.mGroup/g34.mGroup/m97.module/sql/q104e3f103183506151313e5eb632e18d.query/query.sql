DELETE FROM PLM_moduleKeyType
WHERE PLM_moduleKeyType.module_id = {id}