SELECT *
FROM PLM_accountKeyType