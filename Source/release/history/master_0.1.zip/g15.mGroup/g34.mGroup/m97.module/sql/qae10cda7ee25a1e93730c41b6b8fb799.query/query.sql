UPDATE UNIT_module SET 
	scope = '{scope}', 
	status = '{status}' 
WHERE id = {id}