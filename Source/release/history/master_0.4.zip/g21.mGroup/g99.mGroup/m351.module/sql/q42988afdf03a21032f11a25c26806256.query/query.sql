DELETE
FROM PLM_accountToTeam
WHERE account_id = {aid} AND team_id = {tid};