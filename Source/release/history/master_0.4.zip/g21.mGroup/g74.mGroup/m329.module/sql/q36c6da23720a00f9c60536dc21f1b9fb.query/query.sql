SELECT COUNT(*) as count
FROM PLM_account
WHERE username = '{username}';