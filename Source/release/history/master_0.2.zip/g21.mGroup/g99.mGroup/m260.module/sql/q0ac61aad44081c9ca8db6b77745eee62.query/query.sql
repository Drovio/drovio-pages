UPDATE RB_team
SET name = '{name}'
WHERE id = {tid};