INSERT INTO PLM_moduleKeyType (module_id, keyType_id)
VALUES ({id}, {type});