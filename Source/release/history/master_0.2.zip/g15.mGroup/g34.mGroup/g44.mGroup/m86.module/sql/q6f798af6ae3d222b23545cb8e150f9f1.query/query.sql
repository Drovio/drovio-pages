SELECT *
FROM PLM_userGroup
WHERE company_id IS NULL AND active = 1 
ORDER BY name ASC