SELECT COUNT(*) as count
FROM RB_person
WHERE username = '{username}';