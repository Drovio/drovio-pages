DELETE FROM PLM_accountKey
WHERE PLM_accountKey.type_id = 1 AND PLM_accountKey.context = {tid};