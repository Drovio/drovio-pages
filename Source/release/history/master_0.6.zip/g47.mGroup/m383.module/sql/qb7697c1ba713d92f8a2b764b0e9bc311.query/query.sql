SELECT *
FROM AC_app
WHERE id = {app_id} AND active = 1;