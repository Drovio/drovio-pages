<?php
//#section#[header]
// Module Declaration
$moduleID = 92;

// Inner Module Codes
$innerModules = array();
$innerModules['loginPopup'] = 319;
$innerModules['appInfo'] = 358;

// Check Module Preloader Defined in RB Platform (prevent outside executions)
if (!defined("_MDL_PRELOADER_") && !defined("_RB_PLATFORM_"))
	throw new Exception("Module is not loaded properly!");

// Use Platform classes
use \API\Platform\importer;
use \API\Platform\engine;

// Increase module's loading depth
importer::import("ESS", "Protocol", "loaders::ModuleLoader");
use \ESS\Protocol\loaders\ModuleLoader;
ModuleLoader::incLoadingDepth();

// Import Initial Libraries
importer::import("UI", "Html", "DOM");
importer::import("UI", "Html", "HTML");
importer::import("DEV", "Profiler", "logger");

// Use
use \UI\Html\DOM;
use \UI\Html\HTML;
use \DEV\Profiler\logger;

// Code Variables
$_ASCOP = $GLOBALS['_ASCOP'];

// If Async Request Pre-Loader exists, Initialize DOM
if (defined("_MDL_PRELOADER_") && ModuleLoader::getLoadingDepth() === 1)
	DOM::initialize();

// Import Packages
importer::import("API", "Profile");
importer::import("ESS", "Environment");
importer::import("UI", "Modules");
//#section_end#
//#section#[code]
use \ESS\Environment\url;
use \API\Profile\account;
use \UI\Modules\MContent;

// Create Module Page
$pageContent = new MContent($moduleID);
$actionFactory = $pageContent->getActionFactory();

// Build content
$pageContent->build("", "navigationContent", TRUE);

// Activate back button if application viewer is active
$applicationID = engine::getVar("id");
$applicationName = engine::getVar("name");
if (!empty($applicationID) || !empty($applicationName))
{
	// Activate back
	$back = HTML::select(".navigationContent .bar .back")->item(0);
	HTML::addClass($back, "active");
	
	// Activate Application info
	$appInfo = HTML::select(".navigationContent .bar .appInfo")->item(0);
	HTML::addClass($appInfo, "active");
	
	// Set url
	if (!empty($applicationName))
		$applicationUrl = url::resolve("apps", "/".$applicationName);
	else
	{
		$params = array();
		$params['id'] = $applicationID;
		$applicationUrl = url::resolve("apps", "/application.php", $params);
	}
	DOM::attr($appInfo, "href", $applicationUrl);
}

// Return output
return $pageContent->getReport();
//#section_end#
?>