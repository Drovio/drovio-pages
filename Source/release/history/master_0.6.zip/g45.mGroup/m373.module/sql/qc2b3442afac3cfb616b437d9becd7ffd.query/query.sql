SELECT *
FROM RB_team
WHERE uname = '{uname}';